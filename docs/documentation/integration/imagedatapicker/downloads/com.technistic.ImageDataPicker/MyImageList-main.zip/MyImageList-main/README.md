# MyImageList

## A sample ImageDataPicker application.

This project forms part of the [ImageDataPicker Tutorial](https://technistic.github.io/ImageDataPicker/imagedatapicker/tutorials/imagedatapickertoc/). It walks you through the basics of creating a multi-platform application using the **ImageDataPicker Framework**.

![MyImageList](/images/MyImageList@0.5x.png)

To learn more about the **ImageDataPicker Framework** visit the [Official Repository](https://github.com/Technistic/ImageDataPicker) or read the [Documentation](https://technistic.github.io/ImageDataPicker/imagedatapicker/documentation/imagedatapicker/).  

--------

**Copyright &copy; 2025 Technistic Pty Ltd.**
