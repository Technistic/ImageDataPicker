//
//  ContentView.swift
//  MyImageList
//
//  Copyright © 2025 Technistic Pty Ltd.
//  Refer to LICENSE file for licensing terms.
//

import SwiftUI
import SwiftData

struct ContentView: View {
    var body: some View {
        MyImageListView()
    }
}

#Preview {
    ContentView()
        .modelContainer(for: MyImage.self, inMemory: true)
}
